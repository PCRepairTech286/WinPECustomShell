Version 1.0:
First version of Windows PE Custom Shell.
Version 1.5:
Main Window now has no border.
File menu item renamed to Start.